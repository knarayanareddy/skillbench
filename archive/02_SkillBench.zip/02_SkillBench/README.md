# SkillBench — individual project folder

This folder organizes the existing v0.2 baseline for **SkillBench (SKB)**. It does not add an implementation or change completion status.

## Where to start

1. `01_Product_Specification.md` — full original product specification.
2. `02_Product_Contracts/` — this product's API operations plus required shared foundation, recursively included schema dependencies/examples and its four UI workflows.
3. `03_Implementation/` — agent instructions, product focus, original product/foundation backlog and the unchanged complete implementation queue.
4. `04_Product_Fixtures/` — corresponding synthetic fixtures or links to request/response examples.
5. `05_Shared_Baseline/` — **complete, unchanged canonical executable baseline**, including migrations, security/operations rules, tests, tooling, evidence and infrastructure.
6. `06_Shared_Design_Context/` — original shared architecture, research and verification catalog.

## Why the shared baseline is included

The three products share identity, storage, security, jobs and verification primitives. A complete canonical baseline is included in each folder so it can be handed over independently without broken imports, schema references or a missing sibling folder. It intentionally retains the other products' contracts/reference tests as context; the product-focused working views are in `02_Product_Contracts`. This is an organizational split, **not three newly extracted application repositories**.

## Verification

From `05_Shared_Baseline/`, install `requirements-baseline.txt` in an isolated Python environment, then run:

```bash
python -m pytest -q
python scripts/verify_manifest.py
python scripts/release_gate.py
```

The original baseline has 89 passing contract/oracle tests across all three products. That is **not 89 product tests for SkillBench**. The release gate must remain nonzero until the missing integration/independent evidence exists. See `05_Shared_Baseline/evidence/VALIDATION_REPORT.md`.

No actual application, independent agent implementation trial or production readiness is being claimed. Preserve canonical hashes and original gate statuses; do not mark cross-product tickets complete merely because files were reorganized.
