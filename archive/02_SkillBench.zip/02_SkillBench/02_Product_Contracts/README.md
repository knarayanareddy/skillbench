# SkillBench: scoped contracts

Contains 27 domain operations (18 product-specific plus shared foundation), 21 standalone schemas with recursive dependencies, structural examples and four UI workflow screens. Schema objects embedded in OpenAPI are also retained by reference closure. Browser identity and health routes are separately defined in auth-flow.yaml.

These are extracted views, not a new contract revision. Do not independently modify these copies. Make reviewed changes in the canonical 05_Shared_Baseline, regenerate it, then regenerate organizational views. Canonical SQL and executable tests are preserved there intact.
