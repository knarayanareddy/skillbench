# Fixture scope

These are unchanged synthetic baseline fixtures. Paired trials test orchestration/analysis, not skill effectiveness.

Canonical generators, reference oracles and tests remain in ../05_Shared_Baseline.
